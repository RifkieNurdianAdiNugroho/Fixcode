								<div class="menu-item">
									<div class="menu-content pt-8 pb-0">
										<span class="menu-section text-muted text-uppercase fs-8 ls-1">User</span>
									</div>
								</div>
								
								<div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('user/ahli_gizi')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-heartbeat"></i>
											</span>
										</span>
											<span class="menu-title">Ahli Gizi</span>
										</span>
									 </a>
								  </div>

								  <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('user/bidan')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-stethoscope"></i>
											</span>
										</span>
											<span class="menu-title">Bidan</span>
										</span>
									 </a>
								  </div>

								  <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('user/kapus')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-user-md"></i>
											</span>
										</span>
											<span class="menu-title">Kepala Puskesmas</span>
										</span>
									 </a>
								  </div>
								
								 <div class="menu-item">
									<div class="menu-content pt-8 pb-0">
										<span class="menu-section text-muted text-uppercase fs-8 ls-1">Data</span>
									</div>
								 </div>

								  <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('data/kader')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-user"></i>
											</span>
										</span>
											<span class="menu-title">Kader</span>
										</span>
									 </a>
								  </div>

								  <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('data/posyandu')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-medkit"></i>
											</span>
										</span>
											<span class="menu-title">Posyandu</span>
										</span>
									 </a>
								  </div>

								  <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('data/jadwal/posyandu')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-calendar"></i>
											</span>
										</span>
											<span class="menu-title">Jadwal Posyandu</span>
										</span>
									 </a>
								  </div>

								  <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('data/jadwal/vitamin')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-calendar-alt"></i>
											</span>
										</span>
											<span class="menu-title">Jadwal Vitamin</span>
										</span>
									 </a>
								  </div>

								   <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('data/balita')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fas fa-baby"></i>
											</span>
										</span>
											<span class="menu-title">Balita</span>
										</span>
									 </a>
								  </div>

								  <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('data/jadwal/timbang')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-balance-scale"></i>
											</span>
										</span>
											<span class="menu-title">Data Timbang</span>
										</span>
									 </a>
								  </div>
								  
								 <!--  <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('data/hasil')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-file"></i>
											</span>
										</span>
											<span class="menu-title">Laporan</span>
										</span>
									 </a>
								  </div> -->

								 <!--  <div class="menu-item">
									<div class="menu-content pt-8 pb-0">
										<span class="menu-section text-muted text-uppercase fs-8 ls-1">Laporan</span>
									</div>
								 </div> -->

						<!-- 		 <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('laporan/user')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-users"></i>
											</span>
										</span>
											<span class="menu-title">User</span>
										</span>
									 </a>
								  </div>

								  <div data-kt-menu-trigger="click" class="menu-item menu-accordion ">
									<a  href="{{url('laporan/data')}}">
									<span class="menu-link">
										<span class="menu-icon">
											<span class="svg-icon svg-icon-2">
												<i class="fa fa-file-excel-o"></i>
											</span>
										</span>
											<span class="menu-title">Data</span>
										</span>
									 </a>
								  </div> -->