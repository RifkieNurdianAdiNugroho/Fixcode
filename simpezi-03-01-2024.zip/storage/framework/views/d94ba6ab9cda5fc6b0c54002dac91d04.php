<table>
                            <thead>
                                <tr >
                                    <th>No</th>
                                    <th >Nama</th>
                                    <th >No Telepon</th>
                                    <th >Alamat</th>
                                    <th >Pos</th>
                                </tr>
                            </thead>
                            <tbody >
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                       <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->no_tlp); ?></td>
                                        <td>
                                            <small> <?php echo e($item->alamat); ?></small>
                                        </td>
                                        <td>
                                            <?php echo e($item->nama_pos); ?>

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table><?php /**PATH /home/simpezi.my.id/httpdocs/resources/views/dashboard/kader/excel.blade.php ENDPATH**/ ?>