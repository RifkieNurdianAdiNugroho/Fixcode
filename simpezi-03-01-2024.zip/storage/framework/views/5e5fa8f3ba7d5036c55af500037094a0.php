                        <table >
                            <tr>
                                <th colspan="2" rowspan="2" style="padding-top: 6%">No</th>
                                <th colspan="2" rowspan="2" style="padding-top: 6%">Nama Pos</th>
                                <th colspan="2" rowspan="2" style="padding-top: 6%">Nama Bidan</th>
                                <th colspan="2" rowspan="2" style="padding-top: 6%">Nama Anak</th>
                                <th colspan="2" rowspan="2" style="padding-top: 6%">Jenis Kelamin</th>
                                <th colspan="2" rowspan="2" style="padding-top: 6%">Nama Ortu</th>
                                <?php if(isset($data['bulan'])): ?>
                                <?php $__currentLoopData = $data['bulan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulanKey => $bulanItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th colspan="6" style="text-align: center;">
                                    <?php echo e($bulanItem); ?> <?php echo e($data['tahun'][$bulanKey]); ?>

                                </th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php endif; ?>
                               
                            </tr>
                            
                            <tr>
                                <?php if(isset($data['bulan'])): ?>
                                    <?php $__currentLoopData = $data['bulan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulanKey => $bulanItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th colspan="2" style="text-align: center;padding-bottom: 2%;">Umur</th>
                                    <th colspan="2" style="text-align: center;padding-bottom: 2%;">TB</th>
                                    <th colspan="2" style="text-align: center;padding-bottom: 2%;">BB</th>
                                    <th colspan="2" style="text-align: center;padding-bottom: 2%;">Status Gizi</th>
                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tr>
                                <?php if(isset($data['balita'])): ?>
                                <?php $__currentLoopData = $data['balita']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balitaKey => $balitaItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>  
                                   <td colspan="2">
                                        <?php echo e($balitaKey+1); ?>

                                    </td>  
                                    <td colspan="2">
                                        <?php echo e($balitaItem['pos']); ?>

                                    </td>
                                    <td colspan="2">
                                        <?php echo e($balitaItem['bidan']); ?>

                                    </td>
                                    <td colspan="2">
                                        <?php echo e($balitaItem['nama']); ?>

                                    </td>
                                    <td colspan="2">
                                        <?php echo e($balitaItem['jenis_kelamin']); ?>

                                    </td>
                                    <td colspan="2"><?php echo e($balitaItem['ortu']); ?></td>
                                     <?php $__currentLoopData = $data['bulan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulanKeyOne => $bulanItemOne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td colspan="2">
                                      <?php echo e($data['hasil'][$data['jadwal'][$bulanKeyOne]['jadwal_id']][$balitaKey]['umur']); ?>

                                    </td>
                                    <?php if($data['hasil'][$data['jadwal'][$bulanKeyOne]['jadwal_id']][$balitaKey]['umur'] >= 60): ?>
                                    <td colspan="2" style="background-color: red;">
                                    <?php echo e($data['hasil'][$data['jadwal'][$bulanKeyOne]['jadwal_id']][$balitaKey]['tb']); ?>

                                    </td>
                                    <td colspan="2" style="background-color: red;">
                                      <?php echo e($data['hasil'][$data['jadwal'][$bulanKeyOne]['jadwal_id']][$balitaKey]['bb']); ?>

                                    </td>
                                    <?php else: ?>
                                     <td colspan="2" style="background-color: ;">
                                    <?php echo e($data['hasil'][$data['jadwal'][$bulanKeyOne]['jadwal_id']][$balitaKey]['tb']); ?>

                                    </td>
                                    <td colspan="2" style="background-color: ;">
                                      <?php echo e($data['hasil'][$data['jadwal'][$bulanKeyOne]['jadwal_id']][$balitaKey]['bb']); ?>

                                    </td>
                                    <?php endif; ?>
                                    <td colspan="2">
                                        <?php echo e($data['hasil'][$data['jadwal'][$bulanKeyOne]['jadwal_id']][$balitaKey]['status_gizi']); ?>

                                    </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </table>

<?php /**PATH /home/simpezi.my.id/httpdocs/resources/views/dashboard/timbang/excel.blade.php ENDPATH**/ ?>